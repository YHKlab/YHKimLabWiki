import sys
import os
import re
import numpy as np
import matplotlib.pyplot as plt


def read_kresolved_transmission(filename):

    blocks = []
    current = None

    with open(filename, 'r') as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            # 새로운 k-point block 시작
            if line.startswith('# kb='):

                m = re.search(
                    r'kb=\s*([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+w=\s*([^\s]+)',
                    line
                )

                if m is None:
                    continue

                current = {
                    'k': (
                        float(m.group(1)),
                        float(m.group(2)),
                        float(m.group(3))
                    ),
                    'w': float(m.group(4)),
                    'E': [],
                    'T': []
                }

                blocks.append(current)
                continue

            # 일반 주석은 무시
            if line.startswith('#'):
                continue

            # transmission data
            if current is not None:

                data = line.split()

                if len(data) >= 2:
                    current['E'].append(float(data[0]))
                    current['T'].append(float(data[1]))

    if len(blocks) == 0:
        raise RuntimeError("No k-resolved transmission blocks found.")

    # 기준 energy grid
    energy = np.array(blocks[0]['E'])

    # k-weighted transmission
    transmission = np.zeros_like(energy)

    for block in blocks:

        E = np.array(block['E'])
        T = np.array(block['T'])
        w = block['w']

        if len(E) != len(energy):
            raise ValueError("Energy grid length differs between k-points.")

        if not np.allclose(E, energy):
            raise ValueError("Energy grids are different between k-points.")

        transmission += w * T

    return energy, transmission, blocks


# --------------------------------------------------
# Input
# --------------------------------------------------

if len(sys.argv) != 2:
    print("Usage:")
    print("python plot_trans.py scat.TBT.TRANS_Left-Right")
    sys.exit(1)


filename = sys.argv[1]

energy, transmission, blocks = read_kresolved_transmission(filename)


# --------------------------------------------------
# Information
# --------------------------------------------------

print("Input file         :", filename)
print("Number of k-points :", len(blocks))
print("Sum of weights     :", sum(block['w'] for block in blocks))


# --------------------------------------------------
# Plot
# --------------------------------------------------

fig = plt.figure(figsize=(8, 5))
ax = fig.add_subplot(111)

ax.plot(
    energy,
    transmission,
    'k-',
    linewidth=1.8,
    label=os.path.basename(filename)
)

ax.set_xlim(-5, 5)

Tmax = np.max(transmission)

if Tmax > 0:
    ax.set_ylim(0, Tmax * 1.08)

ax.set_xlabel('Energy [eV]', fontsize=15)
ax.set_ylabel('Transmission', fontsize=15)

ax.tick_params(direction='in')

ax.grid()

ax.legend(
    fontsize=10,
    loc='upper right'
)

plt.tight_layout()


# --------------------------------------------------
# Save
# --------------------------------------------------

output_file = 'Transmission.png'

plt.savefig(
    output_file,
    dpi=300,
    bbox_inches='tight'
)

print("Saved:", os.path.abspath(output_file))

plt.close()