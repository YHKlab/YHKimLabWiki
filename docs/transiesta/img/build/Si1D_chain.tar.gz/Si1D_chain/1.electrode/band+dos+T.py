from NanoCore import *
from NanoCore import siesta as s2

import os
import tempfile
import numpy as np
import matplotlib.pyplot as plt

from NanoCore import *
from NanoCore import siesta as s2

import os
import tempfile
import inspect
import numpy as np
import matplotlib.pyplot as plt

import NanoCore.DataTnBand as dtb


# ============================================================
# Python 2 -> Python 3 compatibility patch
# ============================================================
# NanoCore/DataTnBand.py 원본 파일은 수정하지 않음.
# 실행 중 메모리에서만:
#
#     nlines = norb / 10
#
# 를
#
#     nlines = norb // 10
#
# 으로 교체한다.
# ============================================================

_source = inspect.getsource(dtb.DataTnBand)

_source = _source.replace(
    'nlines = norb / 10',
    'nlines = norb // 10'
)

_namespace = dict(dtb.__dict__)

exec(_source, _namespace)

dtb.DataTnBand = _namespace['DataTnBand']


# ============================================================
# XSF compatibility function
# ============================================================
# xv2xsf가 생성한 XSF에는
#
# CRYSTAL
# # comment
# PRIMVEC
#
# 형태의 주석이 들어갈 수 있음.
#
# 구버전 NanoCore read_xsf()는
#
# CRYSTAL
# PRIMVEC
#
# 처럼 바로 붙어 있어야 읽을 수 있으므로,
# 원본 XSF는 건드리지 않고 임시 파일에서만 주석을 제거한다.
# ============================================================

def read_xsf_compat(filename):

    with open(filename, 'r') as f:
        lines = f.readlines()

    clean_lines = []

    for line in lines:

        # 빈 줄 무시
        if not line.strip():
            continue

        # 주석 줄 무시
        if line.lstrip().startswith('#'):
            continue

        clean_lines.append(line)

    # 임시 XSF 파일 생성
    tmp = tempfile.NamedTemporaryFile(
        mode='w',
        suffix='.XSF',
        delete=False
    )

    tmp.writelines(clean_lines)
    tmp.close()

    try:
        atoms = io.read_xsf(tmp.name)

    finally:
        # 임시 파일 삭제
        os.remove(tmp.name)

    return atoms


# ============================================================
# Read x-y data
# ============================================================

def get_xy_array(filename):

    x = []
    y = []

    with open(filename, 'r') as f:

        for line in f:

            line = line.strip()

            # 빈 줄 무시
            if not line:
                continue

            # TBtrans 주석 무시
            if line.startswith('#'):
                continue

            data = line.split()

            if len(data) < 2:
                continue

            x.append(float(data[0]))
            y.append(float(data[1]))

    return np.array(x), np.array(y)


# ============================================================
# Read electrode structure
# ============================================================

atoms = read_xsf_compat('Si1D_Elec.XSF')


# ============================================================
# SIESTA simulation object
# ============================================================

sim = s2.Siesta(atoms)


# ============================================================
# Energy range
# ============================================================

Ef = -2.8280

emin = -10
emax = 5


# ============================================================
# DOS
# ============================================================

E, dos, dos1, dos2 = s2.get_dos(
    emin=emin,
    emax=emax,
    broad=0.1,
    label='Si1D_Elec'
)


# ============================================================
# Band structure
# ============================================================

path, eigs = s2.get_band(
    sim,
    'RUN.fdf',
    label='Si1D_Elec'
)


# ============================================================
# Transmission
# ============================================================
#
# Tutorial 구버전:
#   Si1D_Perf.AVTRANS
#
# 현재 TBtrans:
#   Si1D_Perf.TBT.TRANS_Left-Right
#
# k-point = 1x1x1 이므로 현재 TRANS를 그대로 사용 가능.
# Si1D_Perf.AVTRANS로 복사해뒀다면 첫 번째가 선택됨.
# ============================================================

if os.path.exists('Si1D_Perf.AVTRANS'):

    trans_file = 'Si1D_Perf.AVTRANS'

elif os.path.exists('Si1D_Perf.TBT.TRANS_Left-Right'):

    trans_file = 'Si1D_Perf.TBT.TRANS_Left-Right'

else:

    raise IOError(
        'Transmission file not found.\n'
        'Need Si1D_Perf.AVTRANS or '
        'Si1D_Perf.TBT.TRANS_Left-Right'
    )


E_trans, transmission = get_xy_array(trans_file)

print('Transmission file :', trans_file)


# ============================================================
# Figure
# ============================================================

fig = plt.figure(figsize=(12, 5))

fig1 = fig.add_subplot(131)
fig2 = fig.add_subplot(132)
fig3 = fig.add_subplot(133)

fig.subplots_adjust(wspace=0.35)


# ============================================================
# Band
# ============================================================

for i, eig in enumerate(eigs):

    fig1.plot(path[i], eig)


fig1.set_xlim(0, np.array(path).max())
fig1.set_ylim(emin, emax)

fig1.set_xlabel(
    'Reciprocal coordinate',
    fontsize=15
)

fig1.set_ylabel(
    'Energy [eV]',
    fontsize=15
)

fig1.set_title(
    'Band Structure',
    fontsize=14
)

fig1.tick_params(
    direction='in'
)

fig1.grid()


# ============================================================
# DOS
# ============================================================

fig2.plot(
    dos,
    E
)

fig2.set_xlim(
    0,
    np.array(dos).max()
)

fig2.set_ylim(
    emin,
    emax
)

fig2.set_xlabel(
    'DOS',
    fontsize=15
)

fig2.set_ylabel(
    'Energy [eV]',
    fontsize=15
)

fig2.set_title(
    'Density of States',
    fontsize=14
)

fig2.tick_params(
    direction='in'
)

fig2.grid()


# ============================================================
# Transmission
# ============================================================

fig3.plot(
    transmission,
    E_trans
)

fig3.set_xlim(
    0,
    8
)

fig3.set_ylim(
    emin,
    emax
)

fig3.set_xlabel(
    'Transmission',
    fontsize=15
)

fig3.set_ylabel(
    'Energy [eV]',
    fontsize=15
)

fig3.set_title(
    'Transmission',
    fontsize=14
)

fig3.tick_params(
    direction='in'
)

fig3.grid()


# ============================================================
# Save figure
# ============================================================

plt.tight_layout()

output_file = 'Band_DOS_Transmission.png'

plt.savefig(
    output_file,
    dpi=300,
    bbox_inches='tight'
)

print(
    'Saved :',
    os.path.abspath(output_file)
)

plt.close()