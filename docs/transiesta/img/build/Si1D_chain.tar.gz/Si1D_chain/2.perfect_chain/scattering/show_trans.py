import sys
import os
import numpy as np
import matplotlib.pyplot as plt


def get_xy_array(filename):
    x = []
    y = []

    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith('#'):
                continue

            data = line.split()

            if len(data) < 2:
                continue

            x.append(float(data[0]))
            y.append(float(data[1]))

    return np.array(x), np.array(y)


fig = plt.figure(figsize=(8, 5))
ax = fig.add_subplot(111)

styles = ['k-', 'r--', 'b-.', 'g:']

for i, filename in enumerate(sys.argv[1:]):
    x, y = get_xy_array(filename)

    label = os.path.basename(filename)

    ax.plot(
        x,
        y,
        styles[i % len(styles)],
        label=label
    )


ax.set_xlim(-10, 5)
ax.set_ylim(0, 3)

ax.set_xlabel('Energy [eV]', fontsize=15)
ax.set_ylabel('Transmission', fontsize=15)

ax.tick_params(direction='in')
ax.grid()
ax.legend(fontsize=10)

plt.tight_layout()

# 현재 디렉토리에 저장
output_file = 'Transmission.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight')

print(f'Saved: {os.path.abspath(output_file)}')

plt.close()