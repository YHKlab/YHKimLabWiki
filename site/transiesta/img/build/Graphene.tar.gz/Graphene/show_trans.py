import sys
import os
import re
import numpy as np
import matplotlib.pyplot as plt


def read_transmission(filename):
    """
    범용 TBtrans reader

    1) 일반 2-column:
         E   T
       -> 그대로 읽음

    2) k-resolved:
         # kb= ... w= ...
         E   T
         ...
       -> 각 k-point를 weight로 평균

    최종적으로 항상
        energy, transmission
    한 쌍만 반환
    """

    blocks = []
    current = None

    plain_E = []
    plain_T = []

    with open(filename, 'r') as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            # ------------------------------------------
            # k-point block 시작
            # ------------------------------------------
            if line.startswith('#') and 'kb=' in line:

                m = re.search(
                    r'kb=\s*([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+w=\s*([^\s]+)',
                    line
                )

                if m:

                    current = {
                        'w': float(m.group(4)),
                        'E': [],
                        'T': []
                    }

                    blocks.append(current)

                continue

            # 일반 comment
            if line.startswith('#'):
                continue

            data = line.split()

            if len(data) < 2:
                continue

            try:
                E = float(data[0])
                T = float(data[1])
            except ValueError:
                continue

            # k-resolved block 안
            if current is not None:

                current['E'].append(E)
                current['T'].append(T)

            # 일반 2-column용
            else:

                plain_E.append(E)
                plain_T.append(T)


    # ========================================================
    # k-resolved file
    # ========================================================

    if len(blocks) > 0:

        energy = np.array(blocks[0]['E'], dtype=float)

        transmission = np.zeros_like(
            energy,
            dtype=float
        )

        weight_sum = 0.0

        for block in blocks:

            E = np.array(block['E'], dtype=float)
            T = np.array(block['T'], dtype=float)
            w = block['w']

            if len(E) != len(energy):
                raise RuntimeError(
                    f'Energy grid length mismatch: {filename}'
                )

            if not np.allclose(E, energy):
                raise RuntimeError(
                    f'Energy grid mismatch: {filename}'
                )

            transmission += w * T
            weight_sum += w

        # weight가 1로 normalize되어 있지 않은 경우도 처리
        if weight_sum != 0:
            transmission /= weight_sum

        print(
            f'[k-resolved] {filename} '
            f'| k-points = {len(blocks)} '
            f'| points = {len(energy)}'
        )

        return energy, transmission


    # ========================================================
    # normal 2-column file
    # ========================================================

    if len(plain_E) == 0:
        raise RuntimeError(
            f'No transmission data found: {filename}'
        )

    energy = np.array(plain_E, dtype=float)
    transmission = np.array(plain_T, dtype=float)

    print(
        f'[2-column]   {filename} '
        f'| points = {len(energy)}'
    )

    return energy, transmission


def make_label(filename):

    path = os.path.abspath(filename)

    parent = os.path.dirname(path)

    # .../2.Graphene_k240/OUT_tbtrans/file
    if os.path.basename(parent) == 'OUT_tbtrans':

        return os.path.basename(
            os.path.dirname(parent)
        )

    return os.path.basename(filename)


# ============================================================
# Input
# ============================================================

if len(sys.argv) < 2:

    print('Usage:')
    print('  python show_trans.py file1 [file2 file3 ...]')

    sys.exit(1)


filenames = sys.argv[1:]


# ============================================================
# Plot
# ============================================================

fig, ax = plt.subplots(figsize=(8, 5))

styles = [
    'k-',
    'r--',
    'b-.',
    'g:',
    'm-',
    'c--'
]

all_energy = []


for i, filename in enumerate(filenames):

    energy, transmission = read_transmission(filename)

    all_energy.append(energy)

    ax.plot(
        energy,
        transmission,
        styles[i % len(styles)],
        linewidth=1.8,
        label=make_label(filename)
    )


# ============================================================
# Axis
# ============================================================

emin = min(np.min(E) for E in all_energy)
emax = max(np.max(E) for E in all_energy)

# x축은 실제 Energy [eV] 범위 그대로
ax.set_xlim(emin, emax)

# transmission은 0부터, 위쪽은 matplotlib 자동
ax.set_ylim(bottom=0)

ax.set_xlabel(
    'Energy [eV]',
    fontsize=15
)

ax.set_ylabel(
    'Transmission',
    fontsize=15
)

ax.tick_params(
    direction='in'
)

ax.grid()

ax.legend(
    fontsize=10,
    loc='upper right'
)

plt.tight_layout()


# ============================================================
# Save
# ============================================================

output_file = 'Transmission.png'

plt.savefig(
    output_file,
    dpi=300,
    bbox_inches='tight'
)

print('Saved:', os.path.abspath(output_file))

plt.close()